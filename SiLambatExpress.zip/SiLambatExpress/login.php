<!DOCTYPE html>

<head>
    <meta charset="UTF-8" />
    <title>Login</title>
    <link rel="stylesheet" href="styleLog.css" />
</head>

<Body>
    <div class="box">
        <span class="boerderLine"></span>
        <form action="login_exe.php" method="post">
            <h2>Halaman Login</h2>
            <div class="inputBox">
                <input name="user" type="text" required="required">
                <span>Username</span>
                <i></i>
            </div>
            <div class="inputBox">
                <input name="pass" type="password" required="required">
                <span>Password</span>
                <i></i>
            </div>
            <input type="submit" value="Login">
        </form>
    </div>
</Body>
</html>