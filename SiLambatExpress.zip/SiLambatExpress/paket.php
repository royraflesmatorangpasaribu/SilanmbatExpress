<?php
include 'koneksi.php';

$query = "SELECT * FROM paket";
$sql = mysqli_query($conn, $query);
$no = 1;
// jika button delete di klik maka akan mengambil data nama_pengirim 
if (isset($_POST['delete'])) {
  $nama_pengirim = $_POST['delete'];
  $sql_del = "DELETE FROM paket WHERE nama_pengirim = $nama_pengirim ";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paket -SiLambat Express</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
    <?php
      include 'sidebar.php';
    ?>

    <div class="container-fluid px-4">
                        <h1 class="mt-4">Paket SiLambat Express</h1>
                        <div class="card mb-4">
                            <!-- posisi tabel align = "right" -->
                            <div class="card-body" >
                                Tambah Paket, Edit Paket, Delete Paket
                            </div>
                            
                        </div>
                        <div class="card mb-4">
                            <div class="card-header">
                            
                            <!-- ke kanan : <div class="d-grid gap-2 d-md-flex justify-content-md-end"> -->
                            <!-- ditengah : <div class="d-grid gap-2 col-6 mx-auto"> -->
                                <a href="tambahPaket.php" type="button" class="btn btn-primary">Tambah Paket</a>
                            <!-- prnutup : </div> -->
                            
                            
                            </div>
                         <div class="card-body">
                    <table class="table">
                      <thead class="table-info">
                                        <tr>
                                            <th>No</th>
                                            <th>No Resi</th>
                                            <th>Nama Penerima</th>
                                            <th>Alamat Penerima</th>
                                            <th>No HP Penerima</th>
                                            <th>Berat Paket</th>
                                            <th>Jenis Paket</th>
                                            <th>Aksi</th>
                                            
                                        </tr>
                                    </thead>
                    
                                    <tbody>
                                        <?php while($result = mysqli_fetch_assoc($sql)) { ?>
                                            <tr>
                                            <td><?php echo $no++ ?></td>
                                            <td><?= $result['resi']; ?></td>
                                            <td><?= $result['nama_penerima']; ?></td>
                                            <td><?= $result['alamat_penerima']; ?></td>
                                            <!-- <td><span class="label label-danger">admin</span></td> -->
                                            <td><?= $result['no_hp_penerima']; ?></td>
                                            <td><?= $result['berat_paket']; ?></td>
                                            <td><?= $result['jenis_paket']; ?></td>
                                            <td>
                                                <a href="editPaket.php?update=<?php echo $result['resi']; ?>"><button type="button" class="btn btn-warning">Rizky</button></a>
                                                <a href="?delete=<?php echo $result['resi']; ?>"><button type="button" class="btn btn-danger">Delete</button></a>
                                            </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- Delete -->
                            <?php 
                            if (isset($_GET['delete'])) {
                                $sql_del = mysqli_query($conn, "DELETE FROM paket where resi = '$_GET[delete]'")or die(mysqli_error($conn));
                                echo "<script>alert('Data Paket Berhasil Di Delete');document.location='paket.php'</script>";
                            }
                            ?>
                        </div>
                    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>