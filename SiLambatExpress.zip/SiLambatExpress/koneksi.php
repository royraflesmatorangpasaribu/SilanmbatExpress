<!-- menghubungkan database dengan website -->
<?php
$host = 'localhost';        // webserver yang digunakan , karna disini menggunakan xampp maka defaultnya localhost
$user = 'root';
$pass = '';
$db = 'silambat_express';   // disesuaikan nama database yang digunakan

// mengkoneksikan 
$conn = mysqli_connect($host, $user, $pass, $db);     // ururtannya harus tepat
mysqli_select_db($conn, $db);


?>