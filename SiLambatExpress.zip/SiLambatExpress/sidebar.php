<nav class="navbar navbar-dark fixed-top" style="background-color: #23242a">
    <div class="container-fluid">
        <!-- jika inging di tengah
         <img src="" alt="" style="width: 50px;"> -->
        <a class="navbar-brand" href="#"><b>SILAMBAT EXPRESS</b></a>
        <!-- mengubah color button pada boostrap
        style="background-color: black" -->
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- jadi start -->
        <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
            <div class="offcanvas-header" style="background-color: #23242a">
                <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Menu SiLambat Express</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body" style="background-color: #23242a">
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="prof.php">Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="paket.php"> Paket</a>
                    </li>
                    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                    <li class="nav-item">
                        <!-- mengubah warna text
                        style="color: red" -->
                        <a class="nav-link active" aria-current="page" href="index.php"> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<br><br>