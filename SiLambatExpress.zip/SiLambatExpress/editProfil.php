<?php
include 'koneksi.php';

$sql=mysqli_query($conn, "SELECT * FROM login_admin WHERE id='$_GET[update]'");
$result=mysqli_fetch_array($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Paket -SiLambat Express</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
    <?php
      include 'sidebar.php';
    ?>

     <div class="container-fluid px-4">
                        <h1 class="mt-4">Edit Profil SiLambat Express</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><a href="paket.php">Profil</a></li>
                            <li class="breadcrumb-item active">Edit</li>
                        </ol>
                    
                    <div class="container">
                    <form method="POST" action="#" enctype="multipart/form-data">

                        <!-- User admin -->
                        <div class="mb-3 row">
                            <label for="nama_pengirim" class="col-sm-2 col-form-label">User</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="user" name="user" value="<?php echo $result['user'];?>">
                            </div>
                        </div>

                        <!-- Nama Admin -->
                        <div class="mb-3 row">
                            <label for="nama_penerima" class="col-sm-2 col-form-label">Nama</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo $result['name'];?>" >
                            </div>
                        </div>

                        <!-- Password -->
                        <div class="mb-3 row">
                            <label for="alamat_penerima" class="col-sm-2 col-form-label">Password</label>
                            <div class="col-sm-10">
                                <textarea name="pass" class="form-control" id="pass" rows=3><?php echo $result['pass'];?></textarea>
                            </div>
                        </div>

                        <!-- foto admin -->
                        <div class="mb-3 row">
                            <label for="foto" class="col-sm-2 col-form-label">Foto</label>
                            <div class="col-sm-10">
                                <input type="file" class="form-control" id="foto" name="foto" accept=".jpg, .jpeg, .png">
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" name="submit">Update Data</button>
                        <a href="paket.php" class="btn btn-danger">Kembali</a>
                    </form>
                    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
//ketika button submit diklik maka akan melakukan pengiriman data yang diupdate
if(isset($_POST['submit'])){
    $user = $_POST['user'];
    $name = $_POST['name'];
    $pass = $_POST['pass'];

    // foto
    if ($_FILES['foto']['error'] != 4) {
        $fotolama = $result['foto'];
        if (!empty($fotolama)) {
            unlink("img/$fotolama");
        }
        $namafoto = $_FILES['foto']['name'];
        $tmp_foto = $_FILES['foto']['tmp_name'];
        $foto_ext = strtolower(pathinfo($namafoto, PATHINFO_EXTENSION));
        $allowed_extensions = array('jpg', 'jpeg', 'png');
        if (in_array($foto_ext, $allowed_extensions)) {
            $foto = $namafoto;
            $upload_path = "img/";
            $counter = 1;
            while (file_exists($upload_path . $foto)) {
                $foto = pathinfo($namafoto, PATHINFO_FILENAME) . '_' . $counter . '.' . $foto_ext;
                $counter++;
            }
            move_uploaded_file($tmp_foto, $upload_path . $foto);
        } else {
            echo "<script>alert('foto yang dapat diupload hanya berekstensi jpg, jpeg, png');
            document.location='edit.php'</script>";
            exit();
        }
    } else {
        $foto = $result['foto'];
    }
    $alamat = $_POST['alamat'];

    // query update data paket
    mysqli_query($conn, "UPDATE login_admin SET
    user = '$user',
    name = '$name',
    pass = '$pass',
    foto = '$foto' WHERE id=$_GET[update]") or die(mysqli_error($conn));
    echo "<script>alert('Data Berhasil Di Update');
    document.location='prof.php'</script>";
}
?>