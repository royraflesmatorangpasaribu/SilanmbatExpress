<?php
include 'koneksi.php';
$resi = $_POST['resi'];
$nama_penerima = $_POST['nama_penerima'];
$alamat_penerima = $_POST['alamat_penerima'];
$no_hp_penerima = $_POST['no_hp_penerima'];
$berat_paket = $_POST['berat_paket'];
$jenis_paket = $_POST['jenis_paket'];
$query = "INSERT INTO paket (id, resi, nama_penerima, alamat_penerima, no_hp_penerima, berat_paket, jenis_paket) 
VALUES(NULL, '$resi', '$nama_penerima', '$alamat_penerima', '$no_hp_penerima', '$berat_paket', '$jenis_paket')";
if (mysqli_query($conn, $query)) {
    echo "New record created successfully";
} 
else{
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
header('Location: paket.php');
exit();
?>