<?php
include 'koneksi.php';

$query = "SELECT * FROM paket";
$sql = mysqli_query($conn, $query);
$no = 1;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Admin -SiLambat Express</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
    />
  </head>
  <!-- ubah background
  style = "background-color:aqua" -->
  <body>
    <!-- memanggil sidebar -->
    <?php
      include 'sidebar.php';
    ?>
    
    <div class="container-fluid px-4">
      <h1 class="mt-4">Dashboard</h1>

      <div id="layoutSidenav_content">
        <div class="container-fluid px-4">
          <ol class="breadcrumb mb-4"></ol>
          <div class="table-responsive">
            <table class="table" >
              <tbody>
                <tr>
                  <td>
                    <!-- logo -->
                    <img
                      src="Logo.png"
                      alt="SilambatExpress"
                      width="300"
                      height="300"
                    />
                  </td>
                  <td>
                    <br /><br />
                    SiLambat Express merupakan ekspedisi barang yang didirikan
                    pada tahun 2023<br />
                    <h5><b>Visi :</b></h5>
                    Menjadi perusahaan transportasi darat bertaraf nasional yang
                    bergerak di bidang pengiriman barang dan senantiasa menjalin
                    suatu kerjasama yang terpercaya dalam proses pengiriman
                    barang secara profesional
                    <br />
                    <h5><b>Misi :</b></h5>
                    Tepat waktu
                  </td>
                </tr>
              </tbody>
            </table>

            <div class="card mb-4">
              <!-- kotak pada tulisan Paket on process -->
              <div class="card-header"> 
                <i class="fas fa-table me-1"></i>
                Paket On Proses
              </div>
              
                <table class="table">
                  <thead class="table-info">
                    <tr>
                      <th>No</th>
                      <th>No Resi</th>
                      <th>Nama Penerima</th>
                      <th>Alamat Penerima</th>
                      <th>No HP Penerima</th>
                      <th>Berat Paket</th>
                      <th>Jenis Paket</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!-- mengambil satu baris data dari hasil kueri yang dieksekusi menggunakan ekstensi MySQLi (MySQL Improved) dalam PHP. -->
                    <?php while ($result = mysqli_fetch_assoc($sql)) { ?>
                    <tr>
                      <td><?= $no++ ?></td>
                      <td><?= $result['resi']; ?></td>
                      <td><?= $result['nama_penerima']; ?></td>
                      <td><?= $result['alamat_penerima']; ?></td>
                      <td><?= $result['no_hp_penerima']; ?></td>
                      <td><?= $result['berat_paket']; ?></td>
                      <td><?= $result['jenis_paket']; ?></td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
