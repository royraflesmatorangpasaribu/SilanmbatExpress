<?php
include 'koneksi.php';

$query = "SELECT * FROM login_admin";
$sql = mysqli_query($conn, $query);
?>
<style>
    body{
    background:#eee;
}

.card{
    border:none;
    position:relative;
    overflow:hidden;
    border-radius:8px;
    cursor:pointer;
}

.card:before{
    content:"";
    position:absolute;
    left:0;
    top:0;
    width:4px;
    height:100%;    
    background-color:gray;
    transform:scaleY(1);
    transition:all 0.5s;
    transform-origin: bottom
}

.card:after{
    content:"";
    position:absolute;
    left:0;
    top:0;
    width:4px;
    height:100%;
    background-color:#23242a;
    transform:scaleY(0);
    transition:all 0.5s;
    transform-origin: bottom
}

.card:hover::after{
    transform:scaleY(1);
}

.fonts{
    font-size:11px;
}

</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paket -SiLambat Express</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
    <!-- memanggil sidebar -->
    <?php
      include 'sidebar.php';
    ?>
    <h1 class="mt-4">Profil Admin</h1>
    <div class="container mt-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-7">
            <!-- mengambil satu baris data dari hasil kueri yang dieksekusi menggunakan ekstensi MySQLi (MySQL Improved) dalam PHP. -->
                <?php while($result = mysqli_fetch_assoc($sql)) { ?>
            <div class="card p-3 py-4">
                <!-- untuk foto bulat
                 class="rounded-circle"  -->
                <div class="text-center">
                    <img src="img/<?= $result['foto'] ?>" alt=""  width="200" height="200" class="rounded-circle">
                </div>
                
                <div class="text-center mt-3">
                    <span class="bg-secondary p-1 px-4 rounded text-white">Admin</span>

                    <h5 class="mt-2 mb-0"><?= $result['name']; ?></h5>

                    <span>Programmer</span>

                    <!-- align = "center" -->
                    <div class="px-4 mt-1" >
                        <p class="fonts">SiLambat Express <br>
                        User : <b><?= $result['user']; ?></b> <br>
                        Password : <b><?= $result['pass']; ?></b>
                        </p>
                    </div>
                    <!-- <div align="left"> -->
                    <!-- button edit ambil id dari databas login_admin -->
                    <!-- <div class="d-grid gap-2 d-md-flex justify-content-md-end"> -->
                   <a href="editProfil.php?update=<?php echo $result['id']; ?>"><button type="button" class="btn btn-warning">Edit</button></a>
                    <a href="index.php" class="btn btn-danger">Logout</a>
                    <!-- </div> -->

                    
                </div>
                <?php } ?>
                
               
                
                
            </div>
            
        </div>
        
    </div>
    
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>