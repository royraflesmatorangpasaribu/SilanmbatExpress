<?php
include 'koneksi.php';

$query = "SELECT * FROM login";
$sql = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Admin -SiLambat Express</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
   
<?php
    include 'sidebar.php';
    ?>

    <div class="container-fluid px-4">
                        <h1 class="mt-4">Profil</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">Profil</a></li>
                        </ol>
                        <center>
                        <div class="card mb-4" >
                            <div class="card-body">
                                Hello Admin, Semangat untuk menjalani hari, Berikan yang terbaik :) untuk kesuksesan Ekspedisi SiLambat Express
                            </div>
                        </div>
                        </center>
                        <div>

                            <!-- posisikan tabel align="center" -->
                            <table >
                                <thead>
                                    <tr>
                                        <td><img src="Profile-PNG.png" alt="SilambatExpress" width="200" height="200"></td>
                                    </tr>

                                </thead>
                            </table>
                            <!-- megatur lebar kolom tabel -->
                            <table width="500px">
                                <tr>
                                        <th>Username</th>
                                        <th>Password</th>
                                    </tr>
                                     <tbody>
                                        <?php while($result = mysqli_fetch_assoc($sql)) { ?>
                                            
                                            <tr>
                                    
                                            <td><?= $result['user']; ?></td>
                                            <td><?= $result['pass']; ?></td>
                                      
                                       
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                            </table>
                        </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>