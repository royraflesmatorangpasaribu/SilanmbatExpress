<?php
include 'koneksi.php';

$query = "SELECT * FROM paket";
$sql = mysqli_query($conn, $query);
$no = 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Paket -SiLambat Express</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
    <?php
      include 'sidebar.php';
    ?>

    <div class="container-fluid px-4">
                        <h1 class="mt-4">Tambah Paket SiLambat Express</h1>
                        <!-- <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><a href="paket.php">Paket</a></li>
                            <li class="breadcrumb-item active">Tambah Paket</li>
                        </ol> -->
                    
                    <div class="container">
                    <form method="POST" action="tambahPaket_exe.php" enctype="multipart/form-data">
                        <div class="mb-3 row">
                            <label for="nama_pengirim" class="col-sm-2 col-form-label">No Resi</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="resi" name="resi" >
                                <!-- membuat hint : placeholder="123456789" -->
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="nama_penerima" class="col-sm-2 col-form-label">Nama Penerima</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="nama_penerima" name="nama_penerima" >
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="alamat_penerima" class="col-sm-2 col-form-label">Alamat Penerima</label>
                            <div class="col-sm-10">
                                <textarea name="alamat_penerima" class="form-control" id="alamat_penerima" rows=3></textarea>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="no_hp_penerima" class="col-sm-2 col-form-label">No HP Penerima</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="no_hp_penerima" name="no_hp_penerima" >
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="berat_paket" class="col-sm-2 col-form-label">Berat Paket</label>
                            <div class="col-sm-10">
                                <select name="berat_paket" class="form-select" aria-label="Default select example">
                                    <option selected>Pilih Berat Paket</option>
                                    <option value="1 kg">1 kg</option>
                                    <option value="2 kg">2 kg</option>
                                    <option value="3 kg">3 kg</option>
                                    <option value="4 kg">4 kg</option>
                                    <option value="5 kg">5 kg</option>
                                    <option value="> 5 kg">Lebih dari 5 kg</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="jenis_paket" class="col-sm-2 col-form-label">Jenis Paket</label>
                            <div class="col-sm-10">
                                <select name="jenis_paket" class="form-select" aria-label="Default select example">
                                    <option selected>Pilih Jenis Paket</option>
                                    <option value="Pakaian">Pakaian</option>
                                    <option value="Makanan">Makanan</option>
                                    <option value="Alat Elektronik">Alat Elektronik</option>
                                    <option value="Barang Mudah Pecah">Barang Mudah Pecah</option>
                                    <option value="Otomotif">Otomotif</option>
                                    <option value="Berkas">Berkas</option>
                                </select>
                            </div>
                        </div>
                        <!--lebar di tengah :  <div class="d-grid gap-2 col-6 mx-auto"> -->
                        <!-- di kanan : <div class="d-grid gap-2 d-md-flex justify-content-md-end"> -->
                        <button type="submit" class="btn btn-primary" name="submit">Tambah Data</button>
                        <a href="paket.php" class="btn btn-danger">Kembali</a>
                        <!-- penutup div : </div> -->
                    </form>
    </div>    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>