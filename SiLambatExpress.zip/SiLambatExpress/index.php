<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Website SiLambat Express</title>
    <!-- menghubungkan ke css -->
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>

    <header>
      <!-- tulisan di kiri -->
      <div class="profil">
        Ekspedisi Barang
      </div>
      <ul class="navbar">
        <!-- agar home ke index -->
        <li><a href="index.php"> Home</a></li>
        <!-- agar button login ke login -->
        <li class="btn">
          <a href="login.php">Login</a>
        </li>
      </ul>
    </header>

    <div class="container">
      <div class="banner">
        <div class="muatan">
          <p>Selamat datang di Website SiLambat Express</p>
          <h1>
            Kami Siap Mengantarkan Barang<br /><span>Anda kemana saja</span
            ><br />
          </h1>
          <h2>
            SiLambat Express 
            <div class="tText">
              <div
                class="job"
                data-job1="Cepat"
                data-job2="Sigap"
              ></div>
            </div>
          </h2>
          
        </div>
        <div class="avatar">
          <div class="image-area">
            <div class="img-wrapper">
              <img src="Logo.png" alt="SilambatExpress" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
